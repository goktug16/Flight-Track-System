İyi günler hocam,
Programda mainscreen class'ı main methodu içeriyor bu class çalıştırıldıktan sonra sistem çalışmaya başlıyor ve sistemin çalışma kurallarını anlatan mesaj penceresi beliriyor.
Sistemin kuralları ödev dökümanında belirtilen şekilde yapılmıştır ancak bazı net belirtilmeyen durumlar için lütfen sistem kurallarını anlatan pencereyi okuyunuz yoksa sistemi düzgün çalıştıramayabilirsiniz.
Mesela sistemimde üst taraftan sistem zamanını seçtikten sonra , 'book a flight' butonuna basıldığı anda seçili sistem zamanı kaydedilir eğer sistem zamanını seçmeden butona basarsanız bu durumda uçuşların kalkması beklediğinizden uzun veya kısa sürebilir veya daha kötü bir hataya yol açabilir.
Sistemimin stop butonuna bastıktan sonra , start butonuna basarsanız yeniden başlama gibi bir özelliği yok , stop butonuna basıldığı anda bitmiş uçuşlar 'Flight Informatin.txt' dosyasına yazılır(stop butonunun özelliğinin dökümanda tam belirtilmediği için bu şekilde kodladım).
Pause,resume butonları düzgün bir şekilde çalışmaktadır ancak sistem çalışırken uçuş eklememeniz gerekiyor , pause butonuna bastıktan sonra uçuş eklenebilir ancak bu uçuşların sistemin güncel zamanından sonra olması gerekiyor.Komut satırından sistemin güncel zamanını satır satır görebilirsiniz.
Sistemimin bu kurallar takip edildiğinde düzgün çalıştığına inanıyorum umarım bir hata yoktur.

Sağlıklı günler diliyorum.

Alaaddin Göktuğ Ayar
19011603
Ders Yürütücüsü : Dr.Öğr.Üyesi Yunus Emre Selçuk